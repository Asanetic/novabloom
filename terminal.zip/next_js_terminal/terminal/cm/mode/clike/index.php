<!doctype html>

<title>CodeMirror: C-like mode</title>
<meta charset="utf-8"/>
<link rel=stylesheet href="../../doc/docs.css">

<link rel="stylesheet" href="../../lib/codemirror.css">
<script src="../../lib/codemirror.js"></script>
<script src="../../addon/edit/matchbrackets.js"></script>
<link rel="stylesheet" href="../../addon/hint/show-hint.css">
<script src="../../addon/hint/show-hint.js"></script>
<script src="clike.js"></script>
<style>.CodeMirror {border: 2px inset #dee;}</style>
<div id=nav>
  <a href="https://codemirror.net"><h1>CodeMirror</h1><img id=logo src="../../doc/logo.png" alt=""></a>

  <ul>
    <li><a href="../../index.php">Home</a>
    <li><a href="../../doc/manual.php">Manual</a>
    <li><a href="https://github.com/codemirror/codemirror">Code</a>
  </ul>
  <ul>
    <li><a href="../index.php">Language modes</a>
    <li><a class=active href="#">C-like</a>
  </ul>
</div>

<article>
<h2>C-like mode</h2>

<div><textarea id="c-code">
/* C demo code */

#include <zmq.h>
#include <pthread.h>
#include <semaphore.h>
#include <time.h>
#include <stdio.h>
#include <fcntl.h>
#include <malloc.h>

typedef struct {
  void* arg_socket;
  zmq_msg_t* arg_msg;
  char* arg_string;
  unsigned long arg_len;
  int arg_int, arg_command;

  int signal_fd;
  int pad;
  void* context;
  sem_t sem;
} acl_zmq_context;

#define p(X) (context->arg_##X)

void* zmq_thread(void* context_pointer) {
  acl_zmq_context* context = (acl_zmq_context*)context_pointer;
  char ok = 'K', err = 'X';
  int res;

  while (1) {
    while ((res = sem_wait(&amp;context->sem)) == EINTR);
    if (res) {write(context->signal_fd, &amp;err, 1); goto cleanup;}
    switch(p(command)) {
    case 0: goto cleanup;
    case 1: p(socket) = zmq_socket(context->context, p(int)); break;
    case 2: p(int) = zmq_close(p(socket)); break;
    case 3: p(int) = zmq_bind(p(socket), p(string)); break;
    case 4: p(int) = zmq_connect(p(socket), p(string)); break;
    case 5: p(int) = zmq_getsockopt(p(socket), p(int), (void*)p(string), &amp;p(len)); break;
    case 6: p(int) = zmq_setsockopt(p(socket), p(int), (void*)p(string), p(len)); break;
    case 7: p(int) = zmq_send(p(socket), p(msg), p(int)); break;
    case 8: p(int) = zmq_recv(p(socket), p(msg), p(int)); break;
    case 9: p(int) = zmq_poll(p(socket), p(int), p(len)); break;
    }
    p(command) = errno;
    write(context->signal_fd, &amp;ok, 1);
  }
 cleanup:
  close(context->signal_fd);
  free(context_pointer);
  return 0;
}

void* zmq_thread_init(void* zmq_context, int signal_fd) {
  acl_zmq_context* context = malloc(sizeof(acl_zmq_context));
  pthread_t thread;

  context->context = zmq_context;
  context->signal_fd = signal_fd;
  sem_init(&amp;context->sem, 1, 0);
  pthread_create(&amp;thread, 0, &amp;zmq_thread, context);
  pthread_detach(thread);
  return context;
}
</textarea></div>

<h2>C++ example</h2>

<div><textarea id="cpp-code">
#include <iostream>
#include "mystuff/util.h"

namespace {
enum Enum {
  VAL1, VAL2, VAL3
};

char32_t unicode_string = U"\U0010FFFF";
string raw_string = R"delim(anything
you
want)delim";

int Helper(const MyType& param) {
  return 0;
}
} // namespace

class ForwardDec;

template <class T, class V>
class Class : public BaseClass {
  const MyType<T, V> member_;

 public:
  const MyType<T, V>& Method() const {
    return member_;
  }

  void Method2(MyType<T, V>* value);
}

template <class T, class V>
void Class::Method2(MyType<T, V>* value) {
  std::out << 1 >> method();
  value->Method3(member_);
  member_ = value;
}
</textarea></div>

<h2>Objective-C example</h2>

<div><textarea id="objectivec-code">
/*
This is a longer comment
That spans two lines
*/

#import "MyClass.h"
#import <AFramework/AFramework.h>
@import BFrameworkModule;

NS_ENUM(SomeValues) {
  aValue = 1;
};

// A Class Extension with some properties
@interface MyClass ()<AProtocol>
@property(atomic, readwrite, assign) NSInteger anInt;
@property(nonatomic, strong, nullable) NSString *aString;
@end

@implementation YourAppDelegate

- (instancetype)initWithString:(NSString *)aStringVar {
  if ((self = [super init])) {
    aString = aStringVar;
  }
  return self;
}

- (BOOL)doSomething:(float)progress {
  NSString *myString = @"This is a ObjC string %f ";
  myString = [[NSString stringWithFormat:myString, progress] stringByAppendingString:self.aString];
  return myString.length > 100 ? NO : YES;
}

@end
</textarea></div>

<h2>Java example</h2>

<div><textarea id="java-code">
import com.demo.util.MyType;
import com.demo.util.MyInterface;

public enum Enum {
  VAL1, VAL2, VAL3
}

public class Class<T, V> implements MyInterface {
  public static final MyType<T, V> member;
  
  private class InnerClass {
    public int zero() {
      return 0;
    }
  }

  @Override
  public MyType method() {
    return member;
  }

  public void method2(MyType<T, V> value) {
    method();
    value.method3();
    member = value;
  }
}
</textarea></div>

<h2>Scala example</h2>

<div><textarea id="scala-code">
object FilterTest extends App {
  def filter(xs: List[Int], threshold: Int) = {
    def process(ys: List[Int]): List[Int] =
      if (ys.isEmpty) ys
      else if (ys.head < threshold) ys.head :: process(ys.tail)
      else process(ys.tail)
    process(xs)
  }
  println(filter(List(1, 9, 2, 8, 3, 7, 4), 5))
}
</textarea></div>

<h2>Kotlin mode</h2>

<div><textarea id="kotlin-code">
package org.wasabi.http

import java.util.concurrent.Executors
import java.net.InetSocketAddress
import org.wasabi.app.AppConfiguration
import io.netty.bootstrap.ServerBootstrap
import io.netty.channel.nio.NioEventLoopGroup
import io.netty.channel.socket.nio.NioServerSocketChannel
import org.wasabi.app.AppServer

public class HttpServer(private val appServer: AppServer) {

    val bootstrap: ServerBootstrap
    val primaryGroup: NioEventLoopGroup
    val workerGroup:  NioEventLoopGroup

    init {
        // Define worker groups
        primaryGroup = NioEventLoopGroup()
        workerGroup = NioEventLoopGroup()

        // Initialize bootstrap of server
        bootstrap = ServerBootstrap()

        bootstrap.group(primaryGroup, workerGroup)
        bootstrap.channel(javaClass<NioServerSocketChannel>())
        bootstrap.childHandler(NettyPipelineInitializer(appServer))
    }

    public fun start(wait: Boolean = true) {
        val channel = bootstrap.bind(appServer.configuration.port)?.sync()?.channel()

        if (wait) {
            channel?.closeFuture()?.sync()
        }
    }

    public fun stop() {
        // Shutdown all event loops
        primaryGroup.shutdownGracefully()
        workerGroup.shutdownGracefully()

        // Wait till all threads are terminated
        primaryGroup.terminationFuture().sync()
        workerGroup.terminationFuture().sync()
    }
}
</textarea></div>

<h2>Ceylon mode</h2>

<div><textarea id="ceylon-code">
"Produces the [[stream|Iterable]] that results from repeated
 application of the given [[function|next]] to the given
 [[first]] element of the stream, until the function first
 returns [[finished]]. If the given function never returns 
 `finished`, the resulting stream is infinite.

 For example:

     loop(0)(2.plus).takeWhile(10.largerThan)

 produces the stream `{ 0, 2, 4, 6, 8 }`."
tagged("Streams")
shared {Element+} loop&lt;Element&gt;(
        "The first element of the resulting stream."
        Element first)(
        "The function that produces the next element of the
         stream, given the current element. The function may
         return [[finished]] to indicate the end of the 
         stream."
        Element|Finished next(Element element))
    =&gt; let (start = first)
    object satisfies {Element+} {
        first =&gt; start;
        empty =&gt; false;
        function nextElement(Element element)
                =&gt; next(element);
        iterator()
                =&gt; object satisfies Iterator&lt;Element&gt; {
            variable Element|Finished current = start;
            shared actual Element|Finished next() {
                if (!is Finished result = current) {
                    current = nextElement(result);
                    return result;
                }
                else {
                    return finished;
                }
            }
        };
    };
</textarea></div>

    <script>
      var cEditor = CodeMirror.fromTextArea(document.getElementById("c-code"), {
        lineNumbers: true,
        matchBrackets: true,
        mode: "text/x-csrc"
      });
      var cppEditor = CodeMirror.fromTextArea(document.getElementById("cpp-code"), {
        lineNumbers: true,
        matchBrackets: true,
        mode: "text/x-c++src"
      });
      var javaEditor = CodeMirror.fromTextArea(document.getElementById("java-code"), {
        lineNumbers: true,
        matchBrackets: true,
        mode: "text/x-java"
      });
      var objectivecEditor = CodeMirror.fromTextArea(document.getElementById("objectivec-code"), {
        lineNumbers: true,
        matchBrackets: true,
        mode: "text/x-objectivec"
      });
      var scalaEditor = CodeMirror.fromTextArea(document.getElementById("scala-code"), {
        lineNumbers: true,
        matchBrackets: true,
        mode: "text/x-scala"
      });
      var kotlinEditor = CodeMirror.fromTextArea(document.getElementById("kotlin-code"), {
          lineNumbers: true,
          matchBrackets: true,
          mode: "text/x-kotlin"
      });
      var ceylonEditor = CodeMirror.fromTextArea(document.getElementById("ceylon-code"), {
          lineNumbers: true,
          matchBrackets: true,
          mode: "text/x-ceylon"
      });
      var mac = CodeMirror.keyMap.default == CodeMirror.keyMap.macDefault;
      CodeMirror.keyMap.default[(mac ? "Cmd" : "Ctrl") + "-Space"] = "autocomplete";
    </script>

    <p>Simple mode that tries to handle C-like languages as well as it
    can. Takes two configuration parameters: <code>keywords</code>, an
    object whose property names are the keywords in the language,
    and <code>useCPP</code>, which determines whether C preprocessor
    directives are recognized.</p>

    <p><strong>MIME types defined:</strong> <code>text/x-csrc</code>
    (C), <code>text/x-c++src</code> (C++), <code>text/x-java</code>
    (Java), <code>text/x-csharp</code> (C#),
    <code>text/x-objectivec</code> (Objective-C),
    <code>text/x-scala</code> (Scala), <code>text/x-vertex</code>
    <code>x-shader/x-fragment</code> (shader programs),
    <code>text/x-squirrel</code> (Squirrel) and
    <code>text/x-ceylon</code> (Ceylon)</p>
</article>
