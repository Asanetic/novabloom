<?php
///===server configurations=============

$host="localhost"; // Host name 
$username="root"; // Mysql username 
$password=""; // Mysql password

///===server configurations=============

//===your application database
$ls_application_name="siren";
$application_db='emberbilling';

//===terminal X snippets database===
$snippets_db='lightspeedv10';


//limit table rows data limit 
$datalimit=15;


//========= create new table script
$col_script="
`primkey` int(255) PRIMARY KEY AUTO_INCREMENT,
`snippetid` varchar(500) NOT NULL,
`snippet_title` varchar(500) NOT NULL,
`snippet_details` blob NOT NULL";


$navbar_path="./includes/navbar.php";
$footer_path="./includes/footer.php";
$header_css_scripts="./includes/header_css_scripts.php";
$background_image_path="";
$template_path="./appframe.php";


?>