<?php

if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
date_default_timezone_set("Africa/Nairobi");

$server_conn=mysqli_connect("$host", "$username", "$password") or die("cannot connect"); 

$dbname=$application_db;
$db=$application_db;

$single_db=$application_db;

$single_conn=$server_conn;

mysqli_select_db($server_conn, $application_db);

$mysqliconn=$server_conn;

$asntag=$snippets_db;

if(!isset($_SESSION['dna_session']))
{
  $_SESSION['dna_session']="";
}

////=========== record per page function 
function list_record_per_page($mysqliconn, $sqlstring, $reclimit)
{

  global $recordperpage_data;


  $requested_page = isset($_GET["rectkn"]) ? intval(base64_decode($_GET["rectkn"])) : 1;
  $firstrecords_query=mysqli_query($mysqliconn, "".$sqlstring."");
  $firstrecords_res = mysqli_fetch_row($firstrecords_query);

  $product_count = $firstrecords_res[0];

  $products_per_page = $reclimit;

  $page_count = ceil($product_count / $products_per_page);
  // You can check if $requested_page is > to $page_count OR < 1,
  // and redirect to the page one.

  $first_product_shown = ($requested_page - 1) * $products_per_page;

  $recordperpage_data=array($first_product_shown,$page_count);

  return $recordperpage_data;
  
}



?>