<?php
if (session_status() == PHP_SESSION_NONE) 
{
  session_start();
}

date_default_timezone_set("Africa/Nairobi");

//db declarations

$db="QuickPos";
$QuickPos="QuickPos";


//sqlsrv_connection
$serverName = "127.0.0.1"; //serverName\instanceName
$sqlsrv_username="";
$sqlsrv_password="";


$connectionInfo = array( "Database"=>$db, "UID"=>$sqlsrv_username, "PWD"=>$sqlsrv_password);

$conn = sqlsrv_connect( $serverName, $connectionInfo) or die( print_r( sqlsrv_errors(), true));


$single_db=$db;
$single_conn=$conn;

$datalimit=15;

if(isset($_SESSION["filelim"]))
{
 $datalimit=$_SESSION["filelim"];
}
////=========== record per page function 
?>